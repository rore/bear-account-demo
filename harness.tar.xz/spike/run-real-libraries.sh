#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v mvn >/dev/null || { echo 'BLOCKED: Maven not installed; no CEL-Java binary tests executed' >&2; exit 3; }
command -v npm >/dev/null || { echo 'BLOCKED: npm not installed; no CEL-ES binary tests executed' >&2; exit 3; }

# The compiler is authoritative. Node only loads approved artifacts and plans
# from the signed CheckedExpr, without relying on CEL-ES's checker.
mvn -q -f spike/java/pom.xml -DskipTests package
pushd spike/node >/dev/null
npm install --no-audit --no-fund --ignore-scripts
popd >/dev/null
mkdir -p results/smoke results/export results/trusted-keys

echo 'Stage 1: Boolean arithmetic, typed protobuf fields, conditional, errors'
java -jar spike/java/target/cross-language-cel-spike-0.1.0.jar fixtures/smoke-expressions.json results/smoke fixtures/task-management-domain.yaml
(
 cd spike/node
 node approve.mjs ../../results/smoke ../../results/trusted-keys
 node node-test.mjs ../../results/smoke ../../results/trusted-keys/approval-public.pem ../../fixtures/smoke-expressions.json ../../fixtures/task-management-domain.yaml
)

echo 'Stage 2: Existing 25 semantic fixtures; fail fast on first mismatch'
java -jar spike/java/target/cross-language-cel-spike-0.1.0.jar fixtures/expressions.json results/export fixtures/task-management-domain.yaml
(
 cd spike/node
 node approve.mjs ../../results/export ../../results/trusted-keys
 node node-test.mjs ../../results/export ../../results/trusted-keys/approval-public.pem ../../fixtures/expressions.json ../../fixtures/task-management-domain.yaml
 echo 'Stage 3: Benchmarks'
 node --expose-gc benchmark.mjs ../../results/export ../../results/trusted-keys/approval-public.pem ../../fixtures/expressions.json ../../fixtures/task-management-domain.yaml
)
