import { readFileSync,writeFileSync,existsSync } from 'node:fs';
import { join } from 'node:path';
import { generateKeyPairSync, sign } from 'node:crypto';
const [folder, trustedKeys] = process.argv.slice(2);
if(!folder || !trustedKeys)throw new Error('Usage: node approve.mjs artifact-dir trusted-keys-dir');
// Demo only: a trusted host would sign after human approval using a protected key.
import {mkdirSync} from 'node:fs';mkdirSync(trustedKeys,{recursive:true});
const publicKeyFile=join(trustedKeys,'approval-public.pem');
const privateKeyFile=join(trustedKeys,'approval-private.pem');
if(!existsSync(publicKeyFile)){
 const keys=generateKeyPairSync('ed25519');
 writeFileSync(publicKeyFile,keys.publicKey.export({type:'spki',format:'pem'}));
 writeFileSync(privateKeyFile,keys.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600});
}
const sig=sign(null,readFileSync(join(folder,'manifest.json')),readFileSync(privateKeyFile));
writeFileSync(join(folder,'manifest.sig'),sig);
console.log('Demo signed artifact (this is NOT proof that customer approval occurred). Public key:',publicKeyFile);
