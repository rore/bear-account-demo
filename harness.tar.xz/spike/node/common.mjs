import { readFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash, verify, timingSafeEqual } from 'node:crypto';
import { create, fromBinary, createFileRegistry } from '@bufbuild/protobuf';
import { FileDescriptorSetSchema, TimestampSchema, DurationSchema } from '@bufbuild/protobuf/wkt';
import { CheckedExprSchema } from '@bufbuild/cel-spec/cel/expr/checked_pb.js';
import { celEnv, CelScalar, listType, objectType, plan, isCelError, isCelList } from '@bufbuild/cel';

export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const idPattern = /^[a-z][a-z0-9_]{0,60}$/;
function assertKeys(o,allowed,where){
  if(!o || typeof o!=='object' || Array.isArray(o))throw new Error('Expected object: '+where);
  for(const k of Object.keys(o))if(!allowed.includes(k))throw new Error(`Unrecognized ${where} field ${k}`);
}
function assertDigest(h){if(typeof h!=='string'||!/^[a-f0-9]{64}$/.test(h))throw new Error('Malformed SHA-256 digest');}
const allowedFunctions = new Set([
  '_+_', '_-_', '_*_','_/_', '_%_', '_==_', '_!=_', '_<_', '_<=_', '_>_', '_>=_',
  '_&&_', '_||_', '!_', '-_', '_?_:_', '_[_]', '@in', '_in_', '@not_strictly_false',
  'size', 'duration', 'timestamp', 'getHours'
]);
const MAX_AST = 192;

function safeRead(base, relative) {
  if (typeof relative !== 'string' || !/^(task\.desc|checked\/[a-z][a-z0-9_]*\.pb)$/.test(relative)) {
    throw new Error(`Unexpected artifact path: ${relative}`);
  }
  return readFileSync(join(base, relative));
}

function assertAst(expr) {
  let count = 0;
  function walk(e, depth = 0, folds = 0) {
    if (++count > MAX_AST || depth > 64 || folds > 2) throw new Error('AST/cost limit exceeded');
    const kind = e?.exprKind;
    if (!kind || typeof kind.case !== 'string') throw new Error('Invalid CEL Expr node');
    const v = kind.value;
    switch (kind.case) {
      case 'constExpr': case 'identExpr': return;
      case 'selectExpr': walk(v.operand, depth + 1, folds); return;
      case 'callExpr': {
        if (!allowedFunctions.has(v.function)) throw new Error(`Unapproved CEL function ${v.function}`);
        if (v.function === 'getHours' && v.args.length !== 0) throw new Error('Timezone-dependent function forbidden');
        if (v.target) walk(v.target, depth + 1, folds);
        for (const arg of v.args) walk(arg, depth + 1, folds);
        return;
      }
      case 'comprehensionExpr': {
        for (const p of ['accuInit','iterRange','loopCondition','loopStep','result']) walk(v[p], depth+1, folds+1);
        return;
      }
      case 'listExpr': for (const el of v.elements) walk(el,depth+1,folds); return;
      default: throw new Error(`Unsupported Expr kind ${kind.case}`);
    }
  }
  walk(expr);
  return count;
}

export function loadArtifact(folder, approvalPublicKeyPath, trustedDcmFile) {
  const base = resolve(folder);
  const manifestBytes = readFileSync(join(base,'manifest.json'));
  const signature = readFileSync(join(base,'manifest.sig'));
  const publicKey = readFileSync(resolve(approvalPublicKeyPath));
  if (!verify(null, manifestBytes, publicKey, signature)) throw new Error('Approval signature invalid');
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  assertKeys(manifest,['format','compiler','runner','policy','domain','dcmSha256','descriptors','sourceFixtureSha256','expressions'],'manifest');
  assertKeys(manifest.descriptors,['path','sha256'],'descriptors');
  assertDigest(manifest.descriptors.sha256); assertDigest(manifest.dcmSha256);
  assertDigest(manifest.sourceFixtureSha256);
  if(!Array.isArray(manifest.expressions)||manifest.expressions.length>32)throw new Error('Too many expressions');
  if (!trustedDcmFile || manifest.dcmSha256 !== sha(readFileSync(resolve(trustedDcmFile)))) throw new Error('Trusted DCM fingerprint mismatch');
  if (manifest.format !== 'bex.cel.checked/1' || manifest.compiler !== 'cel-java/0.14.0' ||
    manifest.runner !== '@bufbuild/cel/0.6.1' || manifest.policy !== 'task-expression-policy/1' ||
    manifest.domain !== 'fictional.task-saas/1.0.0') throw new Error('Artifact type/catalog/policy unsupported');
  const descriptorBytes = safeRead(base, manifest.descriptors.path);
  if (sha(descriptorBytes) !== manifest.descriptors.sha256) throw new Error('Descriptor digest mismatch');
  const fdset = fromBinary(FileDescriptorSetSchema, descriptorBytes);
  const reg = createFileRegistry(fdset);
  const taskDesc = reg.getMessage('bex.Task');
  const projectDesc = reg.getMessage('bex.Project');
  if (!taskDesc || !projectDesc) throw new Error('Expected descriptors not in artifact');
  const env = celEnv({
    registry: reg,
    variables: {
      task: objectType(taskDesc), project: objectType(projectDesc),
      tasks: listType(objectType(taskDesc)), big: CelScalar.INT,
      due: objectType(TimestampSchema), window: objectType(DurationSchema)
    }
  });
  const prepared = new Map();
  for (const entry of manifest.expressions) {
    assertKeys(entry,['id','source','sourceSha256','checked','sha256','javaOutputType'],'expression');
    assertDigest(entry.sha256); assertDigest(entry.sourceSha256);
    if(typeof entry.source!=='string'||Buffer.byteLength(entry.source,'utf8')>4096)throw new Error('Expression source too long');
    if (!idPattern.test(entry.id) || prepared.has(entry.id)) throw new Error('Invalid or duplicate expression ID');
    if (sha(Buffer.from(entry.source, 'utf8')) !== entry.sourceSha256) throw new Error('Source digest mismatch');
    const bytes = safeRead(base, entry.checked);
    if (bytes.byteLength > 262144) throw new Error('CheckedExpr blob too large');
    if (sha(bytes) !== entry.sha256) throw new Error('CheckedExpr digest mismatch');
    const checked = fromBinary(CheckedExprSchema, bytes);
    if (!checked.expr || !checked.typeMap || !checked.referenceMap) throw new Error('Missing checked CEL structure');
    const astNodes = assertAst(checked.expr);
    // Java CEL-Java is the authoritative checker. The accepted type/reference maps
    // are part of the signed artifact; CEL-ES plans from CheckedExpr.expr, not these maps.
    // Do not call CEL-ES's incomplete checker or independently approve expressions.
    const rootType = checked.typeMap[checked.expr.id.toString()];
    if (!rootType) throw new Error('Missing Java-checked root type: ' + entry.id);
    if (typeof entry.javaOutputType !== 'string' || !entry.javaOutputType) {
      throw new Error('Missing Java output-type metadata: ' + entry.id);
    }
    // Note: CEL-ES still re-resolves function overloads at execution. Compare values
    // and errors against the Java execution oracle before allowing activation.
    // DO NOT load user JS/host functions. A fixed env and AST whitelist are still necessary.
    let evalFn;
    try {
      evalFn = plan(env, checked);
    } catch (e) {
      throw new Error(`CEL-ES 0.6.1 could not prepare Java-checked expression ${entry.id}: ${e.message}`, {cause:e});
    }
    prepared.set(entry.id, { evalFn, astNodes, byteCount: bytes.byteLength });
  }
  return { manifest, prepared, reg, taskDesc, projectDesc, env };
}

function checkedIntString(x) {
  if (!/^-?(0|[1-9][0-9]*)$/.test(x)) throw new Error('int64 must be decimal string');
  const n = BigInt(x);
  if (n < -(1n<<63n) || n > (1n<<63n)-1n) throw new Error('int64 out of range');
  return n;
}
function assertText(x,limit=4096){if(typeof x !== 'string'||Buffer.byteLength(x,'utf8')>limit)throw new Error('oversized or invalid string');return x;}
function newMessage(schema, data) {
  if (Object.keys(data).some(k => !['id','status','priority','title','version','tags','note','routing','assigneeId'].includes(k))) throw new Error('Unexpected business field');
  const input = {};
  for(const name of ['id','priority','status','title','routing','assigneeId']) if (name in data) input[name] = assertText(data[name]);
  if ('note' in data) { if(data.note === null) throw new Error('null string is not a missing value'); input.optionalNote = { case:'note',value:assertText(data.note) }; }
  if ('tags' in data) {if(!Array.isArray(data.tags)||data.tags.length>12)throw new Error('tag limit'); input.tags=data.tags.map(x=>assertText(x));}
  if ('version' in data) input.version = checkedIntString(data.version);
  return create(schema,input);
}
export function fixtureInput(data, a) {
  if (!Array.isArray(data.tasks) || data.tasks.length > 6) throw new Error('tasks maxItems=6');
  const dueSeconds = checkedIntString(data.due.seconds);
  const windowSeconds = checkedIntString(data.window.seconds);
  for(const n of [data.due.nanos,data.window.nanos]) if(!Number.isInteger(n)||n<0||n>=1000000000)throw new Error('Invalid time nanos');
  return Object.freeze({
    task: newMessage(a.taskDesc,data.task),
    project: newMessage(a.projectDesc,data.project),
    tasks: Object.freeze(data.tasks.map(t=>newMessage(a.taskDesc,t))),
    big: checkedIntString(data.big),
    due: create(TimestampSchema,{seconds:dueSeconds,nanos:data.due.nanos}),
    window: create(DurationSchema,{seconds:windowSeconds,nanos:data.window.nanos})
  });
}
export function normalize(value) {
  if(isCelError(value))return {type:'error',message:value.message};
  if(value === null)return {type:'null',value:null};
  if(typeof value==='bigint')return {type:'int64',value:value.toString()};
  if(typeof value==='string')return {type:'string',value};
  if(typeof value==='boolean')return {type:'bool',value};
  if(isCelList(value)||Array.isArray(value))return {type:'list',value:Array.from(value,normalize)};
  const msg=value?.message ?? value;
  if(msg && typeof msg.seconds==='bigint' && Number.isInteger(msg.nanos))return {type:'timestamp_or_duration',seconds:msg.seconds.toString(),nanos:msg.nanos};
  return {type:'unknown',repr:String(value)};
}
export function execute(a, id, input) {
  const x=a.prepared.get(id);if(!x)throw new Error(`Unknown expression id: ${id}`);
  return normalize(x.evalFn(input));
}
