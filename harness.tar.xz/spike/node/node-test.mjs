import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { loadArtifact, fixtureInput, execute } from './common.mjs';

const [out, keys, fixtures, dcm] = process.argv.slice(2);
if (!out || !keys || !fixtures || !dcm) throw new Error('Usage: node node-test.mjs <artifact-dir> <approval-public.pem> <fixtures.json> <trusted-dcm.yaml>');
const doc = JSON.parse(readFileSync(resolve(fixtures),'utf8'));
const t0=performance.now();
const artifact=loadArtifact(out,keys,dcm);
const prepareMs=performance.now()-t0;
const inputs=fixtureInput(doc.input,artifact);
const javaRecords = JSON.parse(readFileSync(resolve(out,'java-results.json'),'utf8'));
const javaById = new Map(javaRecords.map(r=>[r.id,r]));
let pass=0,fail=0;
const records=[];
function check(cond,label,actual,expected){
 if(cond){pass++;records.push({id:label,status:'PASS'});}
 else{
   fail++;
   const failure={id:label,status:'FAIL',actual,expected};
   records.push(failure);
   console.error(JSON.stringify({firstFailure:failure,passesBeforeFailure:pass},null,2));
   process.exit(1); // Intentionally stop at the first mismatch/overload divergence.
 }
}
for (const test of doc.positive){
 const rec=javaById.get(test.id);
 check(rec?.status==='PASS',`java-${test.id}`,rec,{status:'PASS'});
 const actual=execute(artifact,test.id,inputs);
 const e=test.expected;
 let ok = actual.type===e.type && JSON.stringify(actual.value)===JSON.stringify(e.value);
 if(e.type.startsWith('list<'))ok = actual.type==='list' && JSON.stringify(actual.value.map(v=>v.value))===JSON.stringify(e.value);
 if(e.type==='timestamp')ok = actual.type==='timestamp_or_duration'&&actual.seconds===e.seconds&&actual.nanos===e.nanos;
 check(ok,test.id,actual,e);
}
for (const test of doc.runtimeErrors){
 const rec=javaById.get(test.id);
 check(rec?.status==='PASS',`java-${test.id}`,rec,{status:'PASS'});
 const actual=execute(artifact,test.id,inputs);
 const match=test.class==='overflow'?/overflow/i:/zero|divide/i;
 check(actual.type==='error'&&match.test(actual.message),test.id,actual,{class:test.class});
}
for(const test of doc.compileRejects){const rec=javaById.get(test.id);check(rec?.status==='REJECTED',`java-reject-${test.id}`,rec,{status:'REJECTED'});}
// Node must reject oversized inputs even if the Java compiler had validated the expression.
let tooMany=structuredClone(doc.input);tooMany.tasks=[...doc.input.tasks,...doc.input.tasks,...doc.input.tasks];
let oversizedRejected=false;try{fixtureInput(tooMany,artifact)}catch(e){oversizedRejected=/maxItems/.test(e.message)}
check(oversizedRejected,'oversized-input',oversizedRejected,true);
// Test the signed manifest itself, never just a bare hash.
import {readFileSync as read,writeFileSync as write,mkdtempSync,cpSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join} from 'node:path';
const tmp=mkdtempSync(join(tmpdir(),'cel-integrity-'));
try {
 cpSync(out,tmp,{recursive:true});const p=join(tmp,'manifest.json');const m=read(p);write(p,Buffer.concat([m,Buffer.from('\n')]));
 let rejected=false;try{loadArtifact(tmp,keys,dcm)}catch(e){rejected=/signature/i.test(e.message)}
 check(rejected,'tamper-manifest',rejected,true);
}finally{rmSync(tmp,{recursive:true,force:true})}
const result={versions:{node:process.version,cel:'@bufbuild/cel/0.6.1'},counts:{pass,fail},prepareMs,records};
console.log(JSON.stringify(result,null,2));
if(fail)process.exitCode=1;
