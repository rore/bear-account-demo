import {readFileSync} from 'node:fs';import {performance} from 'node:perf_hooks';
import {loadArtifact,fixtureInput,execute} from './common.mjs';
const [folder,pub,fixtures,dcm]=process.argv.slice(2);if(!folder||!pub||!fixtures||!dcm)throw new Error('Usage: node benchmark.mjs artifact-dir public.pem fixtures.json');
const doc=JSON.parse(readFileSync(fixtures,'utf8'));
global.gc?.();
const rssBeforeLoad=process.memoryUsage().rss;
const heapBeforeLoad=process.memoryUsage().heapUsed;
const a0=performance.now();const a=loadArtifact(folder,pub,dcm);const preparedMs=performance.now()-a0;
global.gc?.();
const rssAfterLoad=process.memoryUsage().rss;
const heapAfterLoad=process.memoryUsage().heapUsed;
const input=fixtureInput(doc.input,a);const id='branch';
// Start warm and exclude one-time initialization from repeated evaluations.
for(let i=0;i<1000;i++)execute(a,id,input);
const N=30000;const first=performance.now();for(let i=0;i<N;i++)execute(a,id,input);const wallMs=performance.now()-first;
let rssBefore=process.memoryUsage().rss;
for(let i=0;i<2000;i++)execute(a,'exists',input);let rssAfter=process.memoryUsage().rss;
console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,expressions:a.prepared.size,bytesChecked:[...a.prepared.values()].reduce((t,x)=>t+x.byteCount,0),prepareMs:preparedMs,ops:N,evalTotalMs:wallMs,avgUs:1000*wallMs/N,rssBeforeLoad,rssAfterLoad,heapBeforeLoad,heapAfterLoad,rssBefore,rssAfter},null,2));
