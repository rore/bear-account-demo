package experiment;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.DescriptorProtos;
import com.google.protobuf.Descriptors;
import com.google.protobuf.DynamicMessage;
import com.google.protobuf.Duration;
import com.google.protobuf.Timestamp;
import dev.cel.common.CelAbstractSyntaxTree;
import dev.cel.common.CelProtoAbstractSyntaxTree;
import dev.cel.common.types.ListType;
import dev.cel.common.types.SimpleType;
import dev.cel.common.types.StructTypeReference;
import dev.cel.compiler.CelCompiler;
import dev.cel.compiler.CelCompilerFactory;
import dev.cel.runtime.CelRuntime;
import dev.cel.runtime.CelRuntimeFactory;
import dev.cel.expr.CheckedExpr;
import dev.cel.expr.Expr;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** A reproducible CEL-Java 0.14.0 compile/export + Java evaluation harness; no framework runtime. */
public final class CompileExpressions {
  private static final ObjectMapper JSON = new ObjectMapper();
  private static final Set<String> FUNCTIONS = Set.of(
      "_+_", "_-_", "_*_", "_/_", "_%_", "_==_", "_!=_", "_<_", "_<=_", "_>_", "_>=_",
      "_&&_", "_||_", "!_", "-_", "_?_:_", "_[_]", "@in", "_in_", "@not_strictly_false",
      "size", "duration", "timestamp", "getHours");
  private static final Descriptors.FileDescriptor TASK_FILE = taskFile();
  private static final Descriptors.Descriptor TASK = TASK_FILE.findMessageTypeByName("Task");
  private static final Descriptors.Descriptor PROJECT = TASK_FILE.findMessageTypeByName("Project");
  private static final CelRuntime RUNTIME = CelRuntimeFactory.plannerRuntimeBuilder()
      .addFileTypes(TASK_FILE, Timestamp.getDescriptor().getFile(), Duration.getDescriptor().getFile()).build();

  public static void main(String[] args) throws Exception {
    if (args.length != 3) {
      System.err.println("Usage: java -jar ... <fixtures/expressions.json> <artifact-directory> <dcm.yaml>");
      System.exit(64);
    }
    Path cases = Path.of(args[0]);
    Path out = Path.of(args[1]);
    Files.createDirectories(out.resolve("checked"));
    byte[] desc = DescriptorProtos.FileDescriptorSet.newBuilder().addFile(TASK_FILE.toProto()).build().toByteArray();
    Files.write(out.resolve("task.desc"), desc);
    JsonNode root = JSON.readTree(Files.readAllBytes(cases));
    var manifest = new LinkedHashMap<String, Object>();
    manifest.put("format", "bex.cel.checked/1");
    manifest.put("compiler", "cel-java/0.14.0");
    manifest.put("runner", "@bufbuild/cel/0.6.1");
    manifest.put("policy", "task-expression-policy/1");
    manifest.put("domain", "fictional.task-saas/1.0.0");
    manifest.put("dcmSha256", hexSha(Files.readAllBytes(Path.of(args[2]))));
    manifest.put("descriptors", Map.of("path", "task.desc", "sha256", hexSha(desc)));
    manifest.put("sourceFixtureSha256", hexSha(Files.readAllBytes(cases)));
    var exprs = new ArrayList<Map<String, Object>>();
    var compileNs = new ArrayList<Long>();
    var results = new ArrayList<Map<String,Object>>();
    int passed = 0;
    for (String section : List.of("positive", "runtimeErrors", "compileRejects")) {
      for (JsonNode spec : root.get(section)) {
        String id = spec.get("id").asText();
        String source = spec.get("source").asText();
        long start = System.nanoTime();
        try {
          CelCompiler cc = compiler();
          CelAbstractSyntaxTree ast = cc.compile(source).getAst();
          checkAst(CelProtoAbstractSyntaxTree.fromCelAst(ast).toCheckedExpr().getExpr());
          long compileTime = System.nanoTime()-start;
          compileNs.add(compileTime);
          if (section.equals("compileRejects")) {
            var failure = Map.of("id", id, "status", "UNEXPECTED_ACCEPT", "source", source);
            System.err.println("FIRST_JAVA_FAILURE " + JSON.writeValueAsString(failure));
            System.exit(2);
          }
          CheckedExpr checked = CelProtoAbstractSyntaxTree.fromCelAst(ast).toCheckedExpr();
          byte[] pb = checked.toByteArray();
          String file = "checked/"+id+".pb";
          Files.write(out.resolve(file), pb);
          var entry = new LinkedHashMap<String, Object>();
          entry.put("id", id); entry.put("source", source); entry.put("sourceSha256", hexSha(source.getBytes(StandardCharsets.UTF_8)));
          entry.put("checked", file); entry.put("sha256", hexSha(pb)); entry.put("javaOutputType", ast.getResultType().name());
          exprs.add(entry);
          Object result;
          try {
            result = RUNTIME.createProgram(ast).eval(javaInput(root.get("input")));
            Object normalized = normalize(result);
            boolean match = section.equals("runtimeErrors") ? false : matchesExpected(normalized, spec.get("expected"));
            results.add(Map.of("id", id, "status", match ? "PASS" : "UNEXPECTED_VALUE", "value", normalized));
          } catch (Exception e) {
            String message = e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
            String category = section.equals("runtimeErrors") ? spec.get("class").asText() : "";
            boolean rightFailure = category.equals("overflow") && message.toLowerCase().contains("overflow") ||
                category.equals("division-by-zero") && (message.toLowerCase().contains("zero") || message.toLowerCase().contains("divide"));
            results.add(Map.of("id", id, "status", rightFailure ? "PASS" : "UNEXPECTED_EVALUATION_ERROR", "message", message));
          }
          if (results.get(results.size()-1).get("status").equals("PASS")) passed++;
        } catch (Exception e) {
          if (section.equals("compileRejects")) {
            results.add(Map.of("id", id, "status", "REJECTED", "message", e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));
            passed++;
          } else {
            results.add(Map.of("id", id, "status", "UNEXPECTED_REJECT", "message", e.toString()));
          }
        }
        // Fail fast: the next construct must not be exercised after a discrepancy.
        Map<String,Object> latest = results.get(results.size()-1);
        if (latest.get("status").toString().startsWith("UNEXPECTED")) {
          System.err.println("FIRST_JAVA_FAILURE " + JSON.writeValueAsString(latest));
          System.exit(2);
        }
      }
    }
    manifest.put("expressions", exprs);
    JSON.writerWithDefaultPrettyPrinter().writeValue(out.resolve("manifest.json").toFile(), manifest);
    JSON.writerWithDefaultPrettyPrinter().writeValue(out.resolve("java-results.json").toFile(), results);
    JSON.writerWithDefaultPrettyPrinter().writeValue(out.resolve("java-perf.json").toFile(), Map.of(
        "jdk", System.getProperty("java.version"), "n", compileNs.size(),
        "compileNsTotal", compileNs.stream().mapToLong(Long::longValue).sum(),
        "compileNsAvg", compileNs.stream().mapToLong(Long::longValue).average().orElse(0.0)));
    System.out.println("Compiled "+exprs.size()+" expressions; harness checks passed "+passed+" / "+
        (root.get("positive").size()+root.get("runtimeErrors").size()+root.get("compileRejects").size())+
        "; artifacts in " + out);
    if (results.stream().anyMatch(r -> r.get("status").toString().startsWith("UNEXPECTED"))) System.exit(2);
  }

  private static CelCompiler compiler() {
    return CelCompilerFactory.standardCelCompilerBuilder()
        .addFileTypes(TASK_FILE, Timestamp.getDescriptor().getFile(), Duration.getDescriptor().getFile())
        .addVar("task", StructTypeReference.create("bex.Task"))
        .addVar("project", StructTypeReference.create("bex.Project"))
        .addVar("tasks", ListType.create(StructTypeReference.create("bex.Task")))
        .addVar("big", SimpleType.INT)
        .addVar("due", SimpleType.TIMESTAMP)
        .addVar("window", SimpleType.DURATION)
        .build();
  }

  /** Enforce an AST policy (not a string regex). Test-only profile intentionally narrow. */
  private static void checkAst(Expr expr) { visit(expr, 0, new int[]{0}); }
  private static void visit(Expr expr, int macroDepth, int[] nodes) {
    if (++nodes[0] > 192 || macroDepth > 2) throw new IllegalArgumentException("AST/cost budget exceeded");
    if (expr.hasCallExpr()) {
      String fn = expr.getCallExpr().getFunction();
      if (!FUNCTIONS.contains(fn)) throw new IllegalArgumentException("Function not approved: "+fn);
      if (fn.equals("getHours") && expr.getCallExpr().getArgsCount() > 0)
        throw new IllegalArgumentException("Timezone-sensitive overload not approved");
      if (expr.getCallExpr().hasTarget()) visit(expr.getCallExpr().getTarget(), macroDepth, nodes);
      for (Expr arg : expr.getCallExpr().getArgsList()) visit(arg, macroDepth, nodes);
    } else if (expr.hasSelectExpr()) {
      visit(expr.getSelectExpr().getOperand(), macroDepth, nodes);
    } else if (expr.hasListExpr()) {
      for (Expr item : expr.getListExpr().getElementsList()) visit(item, macroDepth, nodes);
    } else if (expr.hasStructExpr()) {
      throw new IllegalArgumentException("Constructing arbitrary maps/records is not approved in this spike");
    } else if (expr.hasComprehensionExpr()) {
      var c = expr.getComprehensionExpr();
      visit(c.getIterRange(), macroDepth+1, nodes);
      visit(c.getAccuInit(), macroDepth+1, nodes);
      visit(c.getLoopCondition(), macroDepth+1, nodes);
      visit(c.getLoopStep(), macroDepth+1, nodes);
      visit(c.getResult(), macroDepth+1, nodes);
    } else if (!(expr.hasIdentExpr() || expr.hasConstExpr())) {
      throw new IllegalArgumentException("Unknown CEL AST construct");
    }
  }

  private static Descriptors.FileDescriptor taskFile() {
    try {
      var task = DescriptorProtos.DescriptorProto.newBuilder().setName("Task");
      task.addField(field("id",1,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      task.addField(field("priority",2,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      task.addField(field("status",3,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      task.addField(field("title",4,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      task.addField(field("version",5,DescriptorProtos.FieldDescriptorProto.Type.TYPE_INT64,false));
      task.addField(field("tags",6,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,true));
      task.addOneofDecl(DescriptorProtos.OneofDescriptorProto.newBuilder().setName("optional_note"));
      task.addField(field("note",7,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false).toBuilder().setOneofIndex(0).build());
      var project = DescriptorProtos.DescriptorProto.newBuilder().setName("Project");
      project.addField(field("id",1,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      project.addField(field("routing",2,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      project.addField(field("assignee_id",3,DescriptorProtos.FieldDescriptorProto.Type.TYPE_STRING,false));
      var file = DescriptorProtos.FileDescriptorProto.newBuilder().setName("bex_task.proto")
          .setPackage("bex").setSyntax("proto3")
          .addMessageType(task).addMessageType(project).build();
      return Descriptors.FileDescriptor.buildFrom(file, new Descriptors.FileDescriptor[0]);
    } catch (Descriptors.DescriptorValidationException e) { throw new IllegalStateException(e); }
  }
  private static DescriptorProtos.FieldDescriptorProto field(String name,int n,DescriptorProtos.FieldDescriptorProto.Type t,boolean repeated) {
    return DescriptorProtos.FieldDescriptorProto.newBuilder().setName(name).setNumber(n).setType(t)
        .setLabel(repeated? DescriptorProtos.FieldDescriptorProto.Label.LABEL_REPEATED:DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL).build();
  }
  private static DynamicMessage message(Descriptors.Descriptor d,JsonNode in) {
    var b=DynamicMessage.newBuilder(d);
    for(Descriptors.FieldDescriptor f:d.getFields()){
      JsonNode v=in.get(f.getName());
      if(v==null){String camel=f.getJsonName();v=in.get(camel);}
      if(v==null || v.isNull()) continue;
      if(f.isRepeated()) {var l=new ArrayList<String>();v.forEach(x->l.add(x.asText()));b.setField(f,l);}
      else if(f.getJavaType()==Descriptors.FieldDescriptor.JavaType.LONG) b.setField(f,Long.parseLong(v.asText()));
      else b.setField(f,v.asText());
    }
    return b.build();
  }
  private static Map<String,Object> javaInput(JsonNode in){
    var vars=new HashMap<String,Object>();
    vars.put("task", message(TASK,in.get("task")));
    vars.put("project",message(PROJECT,in.get("project")));
    var tasks=new ArrayList<DynamicMessage>();in.get("tasks").forEach(t->tasks.add(message(TASK,t)));vars.put("tasks",tasks);
    vars.put("big",Long.parseLong(in.get("big").asText()));
    var d=in.get("due"); vars.put("due",Timestamp.newBuilder().setSeconds(Long.parseLong(d.get("seconds").asText())).setNanos(d.get("nanos").asInt()).build());
    var w=in.get("window"); vars.put("window",Duration.newBuilder().setSeconds(Long.parseLong(w.get("seconds").asText())).setNanos(w.get("nanos").asInt()).build());
    return vars;
  }
  private static boolean matchesExpected(Object actual, JsonNode expected) {
    if (expected == null) return false;
    String type = expected.get("type").asText();
    if (type.equals("bool")) return actual instanceof Boolean b && b == expected.get("value").asBoolean();
    if (type.equals("string")) return actual instanceof String s && s.equals(expected.get("value").asText());
    if (type.equals("int64")) return actual instanceof Map<?,?> m && "int64".equals(m.get("type")) && expected.get("value").asText().equals(m.get("value"));
    if (type.equals("timestamp")) return actual instanceof Map<?,?> m && "timestamp".equals(m.get("type")) &&
        expected.get("seconds").asText().equals(m.get("seconds")) && expected.get("nanos").asInt()==((Number)m.get("nanos")).intValue();
    if (type.startsWith("list<")) {
      if (!(actual instanceof List<?> items) || items.size()!=expected.get("value").size()) return false;
      for(int i=0;i<items.size();i++) {
        Object v=items.get(i); JsonNode want=expected.get("value").get(i);
        if(type.equals("list<string>") ? !(v instanceof String s && s.equals(want.asText())) :
           !(v instanceof Map<?,?> m && want.asText().equals(m.get("value")))) return false;
      }
      return true;
    }
    return false;
  }
  private static Object normalize(Object v){
    if(v instanceof Boolean || v instanceof String) return v;
    if(v instanceof Number) return Map.of("type","int64","value",v.toString());
    if(v instanceof Timestamp x) return Map.of("type","timestamp","seconds",Long.toString(x.getSeconds()),"nanos",x.getNanos());
    if(v instanceof java.time.Instant x) return Map.of("type","timestamp","seconds",Long.toString(x.getEpochSecond()),"nanos",x.getNano());
    if(v instanceof java.time.Duration x) return Map.of("type","duration","seconds",Long.toString(x.getSeconds()),"nanos",x.getNano());
    if(v instanceof List<?> x) return x.stream().map(CompileExpressions::normalize).toList();
    return String.valueOf(v);
  }
  private static String hexSha(byte[] bs) throws Exception {var h=MessageDigest.getInstance("SHA-256").digest(bs);var sb=new StringBuilder();for(byte b:h)sb.append(String.format("%02x",b));return sb.toString();}
}
