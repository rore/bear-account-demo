# Shared task-expression fixtures

- `task-management-domain.yaml` and `ir-examples/*.yaml` are copied from the prior fictional task-management language v0 design, without proprietary CLM examples.
- `expressions.json` defines 17 expected-value cases, 2 expected evaluation-error cases, 6 compile/policy rejections and 5 boundary rejection categories.
- The CEL spike deliberately tests typed task/project **subexpressions**. It does not execute the entire Business Extension IR and contains no domain capability invocation, authorization, or effect propagation.
- `int64` data is always a decimal string on JSON boundaries. Java creates protobuf `int64`/long; Node constructs protobuf values and `bigint`.
- `task.note` is a protobuf oneof presence test. `null` is not conflated with absence.
- `due` is 2026-10-28 08:00:00 UTC. The offset form `2026-10-28T10:00:00+02:00` denotes the same instant. The timestamp addition is exactly seven days.
- Runtime input cardinality max is 6 tasks, with 12 tags per task and 4096 bytes per string. Compiler policy restricts expression AST to 192 nodes, 2 nested comprehensions and depth 64 (Node). These are spike limits, not a certified complete cost budget.
- `expected` is independent of compiled outputs and is not derived from running the same CEL expression.
